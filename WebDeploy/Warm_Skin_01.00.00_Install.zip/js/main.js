﻿$(document).ready(function () {

	// Price wrapping fractional part

	var numbers = document.querySelectorAll(".hc-recprice");
	var el;
	for (var i = 0, n = numbers.length; i < n; i++) {
		el = numbers[i];
		el.innerHTML = el.innerHTML.replace(/\.(\d{2})/, ".<span>$1</span>");
	}

	// Show mobile nav
	$('.mobile-nav-btn').click(function () {
		$( ".main-navigation .navbar-nav" ).slideToggle();
	});

	// Bootstrap Select
	$('select').selectpicker();
});