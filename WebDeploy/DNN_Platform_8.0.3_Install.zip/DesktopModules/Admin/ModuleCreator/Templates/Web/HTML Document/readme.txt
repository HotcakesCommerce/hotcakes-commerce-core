Template Name  : HTML Document
Compatible With: DNN 6.x, 7.x

An HTML Document

template.html

(Include any special instructions for this Module Template in this area)