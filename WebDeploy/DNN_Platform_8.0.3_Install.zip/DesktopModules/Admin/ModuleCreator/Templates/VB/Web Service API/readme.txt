Template Name  : Web Service API
Compatible With: DNN 7.x

A Web Service Controller utilizing Web API that will be created in App_Code

templateController.vb
templateRouteMapper.vb

*NOTE: When you create a Class File there will be a momentary delay while the DNN application restarts

(Include any special instructions for this Module Template in this area)