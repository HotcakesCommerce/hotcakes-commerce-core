﻿$(document).ready(function () {
	if (!$('body').data('initCompleted')) {
		init();
		$('body').data('initCompleted', true);
	}
});

// Init Scripts
function init() {
	initDTTG();
	wrapPrice(".hc-record .hc-recprice");
	initSelectPicker();
	expandMobileMenu();
	setPlaceholders();
}

function initDTTG() {
	$('#mainNav li:has(ul)').doubleTapToGo();
}

function wrapPrice(el) {
	var $el = $(el);

	$.each($el, function (i, val) {
		var price = $(this).text();
		var point = price.indexOf(".");
		var toDot = price.slice(0, point + 1);
		var afterDot = price.slice(point + 1, price.length);

		var html = toDot + "<span>" + afterDot + "</span>";

		$(this).html(html);
	});

}

function initSelectPicker() {
	$('#pageWrap').find('select').selectpicker();
}

function expandMobileMenu() {
	var $button = $("#expandDropdownMenu");
	var $header = $("#pageHeader");

	$button.on('click', function (e) {
		e.preventDefault();

		if ($header.hasClass("expanded-menu")) {
			$header.removeClass("expanded-menu");
		} else {
			$header.addClass("expanded-menu");
		}
	});
}

function setPlaceholders() {
	if (!Modernizr.input.placeholder) {
		$('[placeholder]').focus(function () {
			var input = $(this);
			if (input.val() === input.attr('placeholder')) {
				input.val('');
			}
		}).blur(function () {
			var input = $(this);
			if (input.val() === '' || input.val() === input.attr('placeholder')) {
				input.val(input.attr('placeholder'));
			}
		}).blur();

		$('[placeholder]').parents('form').submit(function () {
			$(this).find('[placeholder]').each(function() {
				var input = $(this);
				if (input.val() === input.attr('placeholder')) {
					input.val('');
				}
			});
		});
	}
}