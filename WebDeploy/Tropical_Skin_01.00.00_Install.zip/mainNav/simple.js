$(document).ready(function(e) {
	(function ($) {
		$(".nav-pills > li a").on("mouseover", function (event) {
			var $this = $(this).parent().find("> ul");
			if ($this.length == 0) return;
			dnn.addIframeMask($this[0]);
		});
		$(".dropdown").attr("aria-haspopup", "true");
		$(".dropdown.active").attr("aria-haspopup", "true");
		$(".dropdown-menu").attr("aria-haspopup", "false");
	})(jQuery);
});