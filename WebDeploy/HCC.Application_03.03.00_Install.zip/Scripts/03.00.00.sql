/*
This code removed to prevent the control panel from being added in new installs beginning with Hotcakes Commerce 03.03.00
*/
GO